- Make USB with tool unRAID.
- Replace files  go and key.key into the config folder.
- Edit file "go" with notepad++:
+ Change: export UNRAID_GUID=XXXXXXXXXXXXXXXXXXX with "XXXXXXXXXXXXXXXXXXX" is GUID in tool Unraid USB Creator.
+ Change: export UNRAID_NAME=PanTigon with your name.
+ Change: export UNRAID_DATE=1654646400 with "1654646400" is UNIX timestamp.



Login: root
no password